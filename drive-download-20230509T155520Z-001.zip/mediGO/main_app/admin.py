from django.contrib import admin

from .models import MediUsers, Medicines

# Register your models here.
admin.site.register(MediUsers)
admin.site.register(Medicines)