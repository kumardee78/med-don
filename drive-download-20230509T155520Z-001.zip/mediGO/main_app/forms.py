from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.forms.fields import ChoiceField

from .models import MediUsers, Medicines



class UserRegisterForm(forms.ModelForm):
	CHOICES=[
		("","Select Type"),
		("NGO","NGO"),
		("Donor","Donor"),
		("Volunteer","Volunteer"),
	]
	email = forms.EmailField(widget=forms.TextInput(attrs={'autocomplete':'off','class':'form-control br-radius-zero','placeholder':'Email'}))
	first_name = forms.CharField(max_length = 20,widget=forms.TextInput(attrs={'autocomplete':'off','class':'form-control br-radius-zero','placeholder':'First Name'}))
	last_name = forms.CharField(max_length = 20,widget=forms.TextInput(attrs={'autocomplete':'off','class':'form-control br-radius-zero','placeholder':'Last Name'}))
	type = ChoiceField(choices=CHOICES,widget=forms.Select(attrs={'autocomplete':'off','class':'form-control br-radius-zero','placeholder':'Type'}))
	city = forms.CharField(max_length = 20,widget=forms.TextInput(attrs={'autocomplete':'off','class':'form-control br-radius-zero','placeholder':'City'}))

	def __init__(self, *args, **kwargs):
		super(UserRegisterForm, self).__init__(*args, **kwargs)
		self.fields['username'].widget.attrs.update({
			'autocomplete':'off','class':'form-control br-radius-zero',
			'placeholder':'Username'
		})
		self.fields['password'].widget.attrs.update({
			'autocomplete':'off','class':'form-control br-radius-zero',
			'placeholder':'Password'
		})
		
	class Meta:
		model = MediUsers
		fields = '__all__'

class MedicineForm(forms.ModelForm):

	manufacturer_date = forms.CharField(widget=forms.TextInput(attrs={"onfocus":"(this.type='date')","onblur":"(this.type='text')"}))
	expire_date = forms.CharField(widget=forms.TextInput(attrs={"onfocus":"(this.type='date')","onblur":"(this.type='text')"}))


	def __init__(self, *args, **kwargs):
		super(MedicineForm, self).__init__(*args, **kwargs)
		for field in self.fields:
			x = field.replace("_"," ").title()
			self.fields[field].widget.attrs.update({
			'autocomplete':'off','class':'form-control br-radius-zero',
			'placeholder':x
		})


	class Meta:
		model = Medicines
		fields = ('name','company_name','mg_power','qty','manufacturer_date','expire_date','image')
		# exclude = ('from_user','to_user','approve','volunteer','qr_image_url')