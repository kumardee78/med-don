from django.db import models
from django.db.models.base import Model

# Create your models here.

class MediUsers(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    username = models.CharField(max_length=100)
    email = models.EmailField(null=True)
    type = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    city = models.CharField(max_length=100)

    def __str__(self):
        return self.username

class Medicines(models.Model):
    image = models.ImageField(upload_to='medicines/',null=True,blank=True)
    name = models.CharField("Name",max_length=100)
    company_name = models.CharField("Company Name",max_length=100)
    mg_power = models.CharField("Power",max_length=100)
    qty = models.IntegerField("Quantity")
    # pain_type = models.CharField("Pain Type",max_length=100)
    approve = models.BooleanField(default=False,null=True)
    from_user = models.ForeignKey(MediUsers,related_name='from_user',on_delete=models.SET_NULL,null=True,blank=True)
    to_user = models.ForeignKey(MediUsers,related_name='to_user',on_delete=models.SET_NULL,null=True,blank=True)
    volunteer = models.ForeignKey(MediUsers,related_name='volunteer',on_delete=models.SET_NULL,null=True,blank=True)
    qr_image_url = models.TextField(null=True,blank=True)
    manufacturer_date = models.DateTimeField(null=True,blank=True)
    expire_date = models.DateTimeField(null=True,blank=True)

    def __str__(self):
        return self.name

class Logs(models.Model):
    medicine = models.ForeignKey(Medicines,on_delete=models.SET_NULL,null=True)

    title = models.CharField(max_length=30,null=True,blank=True)
    description = models.CharField(max_length=3000,null=True,blank=True)
    date = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(MediUsers,related_name='user',on_delete=models.SET_NULL,null=True,blank=True)

    
    def __str__(self):
        return self.title + self.description