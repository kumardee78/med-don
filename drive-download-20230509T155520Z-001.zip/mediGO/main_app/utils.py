import smtplib

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from django.conf import settings

def send_mail(sender,receiver,medicine,user):
    me = sender
    you = receiver

    # Create message container - the correct MIME type is multipart/alternative.
    msg = MIMEMultipart('alternative')
    msg['Subject'] = "Medicine is accepted"
    msg['From'] = me
    msg['To'] = you
    # a ="vaibhav"
    html = f"""\
    <html>
    <head></head>
    <body>
        <p>Hello!<br>
        {medicine.name} medicine is accepted by DONOR and NGO. <br/>
        You may check to reach out for delivery.<br/><br/>
        Thank you...
        </p>
    </body>
    </html>
    """
    #part1 = MIMEText(text, 'plain')
    part2 = MIMEText(html, 'html')

    #msg.attach(part1)
    msg.attach(part2)

    mail = smtplib.SMTP('smtp.gmail.com', 587)
    mail.ehlo()
    mail.starttls()
    mail.login(settings.EMAIL_HOST_USER, settings.EMAIL_HOST_PASSWORD)
    mail.sendmail(me, you, msg.as_string())
    mail.quit()