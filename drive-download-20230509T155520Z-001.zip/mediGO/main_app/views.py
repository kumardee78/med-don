from django.forms.models import inlineformset_factory
from django.shortcuts import redirect, render
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm

from .utils import send_mail
from .forms import MedicineForm, UserRegisterForm
from .models import Logs, MediUsers, Medicines
from qrcode import make
# from django.core.mail import send_mail
from django.core.mail import EmailMessage

from django.conf import settings

def index(request):
	return render(request,"main_app/index.html")


def register(request):
	context={}
	if request.method == 'POST':
		form = UserRegisterForm(request.POST)
		if form.is_valid():
			form.save()
			messages.success(request, f'Your account has been created ! You are now able to log in')
			return redirect('login')
		else:
			print(form.errors)
			messages.error(request,form.errors)
	else:
		form = UserRegisterForm()
	context['request']=request
	context['form'] = form
	return render(request, 'main_app/sign_up.html', context)

################ login forms###################################################
def login_page(request):
	print(request.session.get("user_type"))
	context={}
	if request.method == 'POST':

		# AuthenticationForm_can_also_be_used__
		type = request.POST['type']
		username = request.POST['username']
		password = request.POST['password']
		user = MediUsers.objects.filter(username=username,password=password,type=type).first()
		print(user)
		if user:
			request.session['username'] = username
			request.session['user_type'] = user.type
			messages.success(request, f' welcome {username} !!')
			return redirect('home')
		else:
			messages.error(request, f'Username and/or password incorrect. Please try again.')
	form = AuthenticationForm()
	context['request']=request
	context['form']=form
	return render(request, 'main_app/login.html', context)

def logout_page(request):
	request.session.delete()
	messages.success(request,"Logged out successfully.")
	return redirect('/login')


def create_medicine(request):
	context={}
	if request.method == 'POST':
		print(request.FILES)
		form = MedicineForm(request.POST)
		if form.is_valid():
			instance = form.save(commit=False)
			user = MediUsers.objects.get(username=request.session.get('username',None))
			instance.from_user = user
			instance.image = request.FILES['image']
			instance.save()

			Logs.objects.create(medicine=instance,title='Medicine is Created',description=f'Medicine is created by {user.first_name} {user.last_name} {user.type}.',user=user)
			messages.success(request, f'Medicine is uploaded.')
		else:
			print(form.errors)
			messages.error(request,form.errors)
	else:
		form = MedicineForm()
	context['request']=request
	context['form']=form
	context['title_medi'] = 'Donate a Medicine'
	return render(request, 'main_app/donate_medicine.html', context)

def donor_medicine(request):
	context={}
	username = request.session.get('username',None)
	user = MediUsers.objects.filter(username=username).first()
	medicines = Medicines.objects.filter(from_user=user,approve=False)
	context['medicines'] = medicines
	context['request']=request
	return render(request,'main_app/donor_medicines.html',context)


def request_medicine(request):
	context={}
	if request.method == 'POST':
		form = MedicineForm(request.POST)
		if form.is_valid():
			instance = form.save(commit=False)
			user = MediUsers.objects.get(username=request.session.get('username',None))
			instance.from_user = user
			instance.image = request.FILES['image']
			instance.save()
			Logs.objects.create(medicine=instance,title='Medicine is requested.',description=f'Medicine is requested by {user.first_name} {user.last_name} {user.type}.',user=user)
			messages.success(request, f'Medicine is uploaded.')
		else:
			print(form.errors)
			messages.error(request,form.errors)
	else:
		form = MedicineForm()
	context['request']=request
	context['form']=form
	context['title_medi'] = 'Request a Medicine'
	return render(request, 'main_app/donate_medicine.html', context)


def donor_notification(request,pk=None):
	context={}
	if pk:
		print(request.session)
		username = request.session.get('username',None)
		print("username---",username)
		user = MediUsers.objects.filter(username=username).first()
		medicine = Medicines.objects.get(id=pk)
		if request.session.get("user_type")=="Volunteer":
			medicine.volunteer = user

			medicine_data = {
				"medicine_name":medicine.name,
				"donor":medicine.from_user.first_name +" "+ medicine.from_user.last_name
			}

			image = make(medicine_data)
			import os
			file_url = os.path.join(settings.BASE_DIR,f"static/qr_codes/{medicine.name}.png")
			image.save(f"static/qr_codes/{medicine.name.strip()}.png")
			medicine.qr_image_url = f"/static/qr_codes/{medicine.name.strip()}.png"

			medicines = Medicines.objects.filter(volunteer=user)
			context['medicines'] = medicines
		else:
			volunteers_emails = [email[0] for email in MediUsers.objects.filter(type='Volunteer').values_list('email')]
			for email in volunteers_emails:
				send_mail(settings.EMAIL_HOST_USER,email,medicine,user)
			print("Email sent.")
			Logs.objects.create(medicine=medicine,title='Medicine is Accepted.',description=f'Medicine is accepted by {user.first_name} {user.last_name} {user.type}.',user=user)
			medicine.to_user = user
		medicine.save()
		messages.info(request,"Medicine is assigned to you.")
		if request.session.get("user_type")=="NGO":
			return render(request,'main_app/assigned_medicines.html')
		elif request.session.get("user_type")=="Volunteer":
			Logs.objects.create(medicine=medicine,title='Medicine is Accepted.',description=f'Medicine is accepted by {user.first_name} {user.last_name} {user.type}.',user=user)
			return render(request,'main_app/confirmed_medicines.html')
			

	medicines = Medicines.objects.filter(from_user__type='NGO',to_user__isnull=True,approve=False)
	context['medicines'] = medicines
	context['request'] = request
	return render(request,'main_app/notification_donor.html',context)


def ngo_medicines(request):
	context={}
	username = request.session.get('username',None)
	user = MediUsers.objects.filter(username=username).first()
	medicines = Medicines.objects.filter(from_user__type='Donor',to_user__isnull=True,approve=False)
	context['medicines'] = medicines
	context['request']=request
	return render(request,'main_app/ngo_medicines.html',context)


def assigned_medicines(request):
	context={}
	username = request.session.get('username',None)
	user = MediUsers.objects.filter(username=username).first()
	medicines = Medicines.objects.filter(to_user=user)
	context['medicines'] = medicines
	context['request']=request
	return render(request,'main_app/assigned_medicines.html',context)

def view_medicines(request):
	context={}
	username = request.session.get('username',None)
	user = MediUsers.objects.filter(username=username).first()
	medicines = Medicines.objects.filter(from_user__isnull=False,to_user__isnull=False,volunteer__isnull=True)
	context['medicines'] = medicines
	context['request'] = request
	return render(request,'main_app/view_medicines.html',context)

def assigned_medicines_to_volunteer(request):
	context={}
	username = request.session.get('username',None)
	user = MediUsers.objects.filter(username=username).first()
	medicines = Medicines.objects.filter(volunteer=user)
	context['medicines'] = medicines
	context['request']=request
	return render(request,'main_app/confirmed_medicines.html',context)


def logs(request,pk):
	context={}
	medicine = Medicines.objects.get(id=pk)
	logs = Logs.objects.filter(medicine=medicine)

	context['logs']=logs
	context['medicine_name'] = medicine.name	
	
	return render(request,'main_app/logs.html',context)