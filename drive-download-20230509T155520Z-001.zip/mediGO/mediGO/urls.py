"""mediGO URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from main_app.views import assigned_medicines, assigned_medicines_to_volunteer, create_medicine, donor_medicine, donor_notification, index, login_page, logout_page, logs, ngo_medicines, register, request_medicine, view_medicines
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',index,name="home"),
    path('sign_up/',register,name="sign_up"),
    path('login/',login_page,name="login"),
    path('logout/',logout_page,name="logout"),
    
    #donor
    path('donate-medicine/',create_medicine,name="create-medicine"),
    path('donar-medicine/',donor_medicine,name="donor-medicine"),
    path('donar-notification/',donor_notification,name="donor-notification"),
    path('medicine/<int:pk>',donor_notification,name="donor-notification"),

    #ngo
    # path('medicine/<int:pk>',ngo_notification,name="ngo-notification"),
    path('request-medicine/',request_medicine,name="request-medicine"),
    path('ngo-medicines/',ngo_medicines,name="ngo-medicines"),
    path('assigned-medicines/',assigned_medicines,name="assigned-medicines"),

    #volunteer
    path('confirmed-medicines/',assigned_medicines_to_volunteer,name="assigned-medicines-volunteer"),
    path('view-medicines/',view_medicines,name="view-medicines"),

    path('logs/<int:pk>',logs,name="logs"),



]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
